package com.portfolio.ngz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NgzApplication {

	public static void main(String[] args) {
		SpringApplication.run(NgzApplication.class, args);
	}

}
